package pageObjects;

import org.openqa.selenium.By;
import utilities.DriverManager;

public class CarPageObject extends DriverManager {
   // public String searchType="//select[@id='SearchType']";
    public String motorLink="//a[@id='SearchTabs1_MotorsLink']";
    public String usedCarsLink="//a[@id='SiteHeader_SiteTabs_SubNavMotors_LinkUsedCars']";
    public String userCarsListLogo="//h1[contains(text(),'Used Cars')]";
    public String moreLink="//strong[contains(text(),'more...')]";
    public String motorListing="//a[@id='ListingsTitle_MotorsListingTypeControl_All_on']";



}
