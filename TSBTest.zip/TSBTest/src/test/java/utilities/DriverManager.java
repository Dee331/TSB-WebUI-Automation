package utilities;

import org.junit.Assert;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class DriverManager {
        public static WebDriver driver;
        public static Properties prop;

        public WebDriver getDriver() throws IOException {
//create an object for the property file
            prop = new Properties();

            // Data from Global Configuration file(Example- URL)

            FileInputStream fis = new FileInputStream(
                    System.getProperty("user.dir") + "/src/test/java/utilities/GlobalConfig.properties");

            prop.load(fis);
///pick the name of the browser from property file
            String browser = prop.getProperty("Browser");
///initiate the browser

            if (browser.equals("googlechrome")) {

                WebDriverManager.chromedriver().setup();

                driver = new ChromeDriver();

            }

            //get the URL from property file
            driver.get(prop.getProperty("BaseUrl"));

            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
            return  driver;
        }
}






