package stepDefinition;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import utilities.DriverManager;

public class Hooks {

    @After
    public void afterScenario(Scenario scenario) {

        WebDriver driver = DriverManager.driver;
//take a screenshot on assertion failure and save in centralize folder
        if (scenario.isFailed()) {
            try {
                // Logger.info(scenario.getName() + " is failed");

                final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
                scenario.embed(screenshot, "image/png");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        driver.close();

    }


}
