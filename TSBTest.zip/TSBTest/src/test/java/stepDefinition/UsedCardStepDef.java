package stepDefinition;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pageObjects.CarPageObject;
import utilities.DriverManager;
import java.util.concurrent.TimeUnit;

public class UsedCardStepDef extends DriverManager {
    //create an object of driver manager
    DriverManager drivermanager = new DriverManager();

    //create an object for locators available on the page
    CarPageObject test_object = new CarPageObject();

//declare the driver public
    public WebDriver driver;

    @Given("^The TradeMe Sandbox web site is up and running$")
    public void the_trademe_sandbox_web_site_is_up_and_running() throws Throwable
    {
        //initiate the browser and enter URL from a file
        WebDriver driver = drivermanager.getDriver();
        this.driver = driver;
    }

    @When("^user clicks Motors tab$")
    public void user_clicks_motors_tab() throws Throwable {
        //motor link available on the page
        driver.findElement(By.xpath(test_object.motorLink)).isDisplayed();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //click on the motor link
        driver.findElement(By.xpath(test_object.motorLink)).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @And("^user sees an option check used car$")
    public void user_sees_an_option_check_used_car() throws Throwable {
        //used car link is available on the page
        driver.findElement(By.xpath(test_object.usedCarsLink)).isDisplayed();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @And("^user clicks used car link to check used cars$")
    public void user_clicks_used_car_link_to_check_used_cars() throws Throwable {
        //click on the link used cars
        driver.findElement(By.xpath(test_object.usedCarsLink)).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @Then("^all used cars list displays$")
    public void all_used_cars_list_displays() throws Throwable {
        //assertion-> used car Logo appearing
        driver.findElement(By.xpath(test_object.userCarsListLogo)).isDisplayed();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //click on the more link
        driver.findElement(By.xpath(test_object.moreLink)).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //assertion-> listed cars appearing on the page
        driver.findElement(By.xpath(test_object.motorListing)).isDisplayed();
    }
}